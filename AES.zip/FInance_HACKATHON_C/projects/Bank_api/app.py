from flask import Flask, jsonify, render_template, request
import datetime

app = Flask(__name__)

# Mock user bank account
data = {
    "account_id": "1234567890",
    "balance": 100000,
    "transactions": [],
    "allowed_devices": ["Phone1"],
    "last_location": "Mumbai"
}

# Fraud detection function
def is_fraudulent(transaction):
    amount = transaction["amount"]
    device = transaction["device"]
    location = transaction["location"]
    
    if amount > 50000:
        return True, "High transaction amount detected"
    if device not in data["allowed_devices"]:
        return True, "Transaction from an unrecognized device"
    if location != data["last_location"]:
        return True, "Transaction from an unusual location"
    
    return False, "Transaction approved"

@app.route('/')
def home():
    return render_template("index.html", balance=data["balance"], transactions=data["transactions"])

@app.route('/transactions')
def get_transactions():
    return jsonify({"balance": data["balance"], "transactions": data["transactions"]})

@app.route('/trigger_transaction', methods=['POST'])
def trigger_transaction():
    transaction = request.json
    is_fraud, message = is_fraudulent(transaction)

    if is_fraud:
        transaction["status"] = "blocked"
    else:
        transaction["status"] = "approved"
        data["balance"] -= transaction["amount"]
    
    transaction["timestamp"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    data["transactions"].insert(0, transaction)  # Add to history

    return jsonify({"status": transaction["status"], "message": message, "balance": data["balance"]})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
