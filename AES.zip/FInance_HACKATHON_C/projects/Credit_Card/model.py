import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score, average_precision_score, mean_squared_error
from sklearn.ensemble import RandomForestClassifier
import xgboost as xgb
from sklearn.linear_model import LinearRegression
import pickle
import time
import warnings

warnings.filterwarnings('ignore')

# Load the dataset
print("Loading dataset...")
df = pd.read_csv('credit_card_fraud_dataset_250k.csv')

# Data Preprocessing
print("\nPreprocessing data...")
X = df.drop('IsFraud', axis=1)
y = df['IsFraud']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

scaler = StandardScaler()
numeric_cols = ['TransactionAmount', 'TransactionTime']
X_train[numeric_cols] = scaler.fit_transform(X_train[numeric_cols])
X_test[numeric_cols] = scaler.transform(X_test[numeric_cols])

preprocessing = {'scaler': scaler, 'numeric_cols': numeric_cols}
with open('preprocessing_components.pkl', 'wb') as f:
    pickle.dump(preprocessing, f)

print(f"Training set shape: {X_train.shape}")
print(f"Test set shape: {X_test.shape}")

# Function to evaluate model
def evaluate_model(model, X_train, X_test, y_train, y_test, model_name):
    start_time = time.time()
    model.fit(X_train, y_train)
    train_time = time.time() - start_time

    start_time = time.time()
    y_pred = model.predict(X_test)
    inference_time = time.time() - start_time

    if model_name == 'Linear Regression (Amount)':
        mse = mean_squared_error(y_test, y_pred)
        print(f"\n--- {model_name} Results ---")
        print(f"Mean Squared Error: {mse:.4f}")
        print(f"Training time: {train_time:.2f} seconds")
        print(f"Inference time: {inference_time:.2f} seconds")
        return {'model': model, 'name': model_name, 'mse': mse, 'train_time': train_time, 'inference_time': inference_time}
    else:
        accuracy = accuracy_score(y_test, y_pred)
        cr = classification_report(y_test, y_pred, output_dict=True)
        roc_auc = roc_auc_score(y_test, model.predict_proba(X_test)[:, 1])
        pr_auc = average_precision_score(y_test, model.predict_proba(X_test)[:, 1])
        cm = confusion_matrix(y_test, y_pred)

        print(f"\n--- {model_name} Results ---")
        print(f"Accuracy: {accuracy:.4f}")
        print(f"Precision (Fraud): {cr['1']['precision']:.4f}")
        print(f"Recall (Fraud): {cr['1']['recall']:.4f}")
        print(f"F1-Score (Fraud): {cr['1']['f1-score']:.4f}")
        print(f"ROC AUC: {roc_auc:.4f}")
        print(f"PR AUC: {pr_auc:.4f}")
        print(f"Training time: {train_time:.2f} seconds")
        print(f"Inference time: {inference_time:.2f} seconds")

        return {'model': model, 'name': model_name, 'accuracy': accuracy, 'precision': cr['1']['precision'],
                'recall': cr['1']['recall'], 'f1': cr['1']['f1-score'], 'roc_auc': roc_auc, 'pr_auc': pr_auc,
                'train_time': train_time, 'inference_time': inference_time, 'confusion_matrix': cm}

# Train and evaluate models
print("\nTraining and evaluating models...")
models = [
    {'name': 'Random Forest', 'model': RandomForestClassifier(n_estimators=100, class_weight='balanced', random_state=42)},
    {'name': 'XGBoost', 'model': xgb.XGBClassifier(n_estimators=100, scale_pos_weight=9, random_state=42)},
    {'name': 'Linear Regression (Amount)', 'model': LinearRegression()}
]

results = []
for model_info in models:
    if model_info['name'] == 'Linear Regression (Amount)':
        result = evaluate_model(model_info['model'], X_train.drop('TransactionAmount', axis=1), X_test.drop('TransactionAmount', axis=1), X_train['TransactionAmount'], X_test['TransactionAmount'], model_info['name'])
    else:
        result = evaluate_model(model_info['model'], X_train, X_test, y_train, y_test, model_info['name'])
    results.append(result)

# Find the best model based on F1 score
best_model = max(results[:2], key=lambda x: x['f1'])
print(f"\nBest model: {best_model['name']} with F1-Score: {best_model['f1']:.4f}")

# Tuning the best model
print(f"\nFine-tuning the best model ({best_model['name']})...")
param_grid = {
    'n_estimators': [100, 200],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5, 10]
} if best_model['name'] == 'Random Forest' else {
    'n_estimators': [100, 200],
    'learning_rate': [0.01, 0.1, 0.2],
    'max_depth': [3, 5, 7]
}

grid_search = GridSearchCV(best_model['model'], param_grid, cv=3, scoring='f1', n_jobs=-1)
grid_search.fit(X_train, y_train)

print(f"Best parameters: {grid_search.best_params_}")
best_tuned_model = grid_search.best_estimator_

tuned_result = evaluate_model(best_tuned_model, X_train, X_test, y_train, y_test, f"Tuned {best_model['name']}")

# Save the best model
with open('best_fraud_detection_model.pkl', 'wb') as f:
    pickle.dump(best_tuned_model, f)

print("\nBest model saved as 'best_fraud_detection_model.pkl'")

# Model Comparison
model_comparison = pd.DataFrame([
    {'Model': r['name'], 'Accuracy': r.get('accuracy', None), 'Precision': r.get('precision', None), 'Recall': r.get('recall', None),
     'F1 Score': r.get('f1', None), 'ROC AUC': r.get('roc_auc', None), 'PR AUC': r.get('pr_auc', None), 'MSE': r.get('mse', None),
     'Training Time (s)': r['train_time'], 'Inference Time (s)': r['inference_time']} for r in results
])

print("\nModel Comparison:")
print(model_comparison)

# Save model comparison to CSV
model_comparison.to_csv('model_comparison.csv', index=False)