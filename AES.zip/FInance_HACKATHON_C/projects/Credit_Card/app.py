from flask import Flask, render_template, request
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

app = Flask(__name__)

# Generate synthetic dataset
np.random.seed(42)
data_size = 250000
data = pd.DataFrame({
    "TransactionAmount": np.random.randint(1, 10000, data_size),
    "TransactionTime": np.random.randint(1, 1440, data_size),  # 24 hours in minutes
    "IsForeignTransaction": np.random.randint(0, 2, data_size),
    "IsHighRiskCountry": np.random.randint(0, 2, data_size),
    "DeviceChange": np.random.randint(0, 2, data_size),
    "VelocityFlag": np.random.randint(0, 2, data_size),
    "CardPresent": np.random.randint(0, 2, data_size),
    "BehaviorDeviation": np.random.randint(0, 2, data_size),
    "RepeatedPattern": np.random.randint(0, 2, data_size),
})

# Fraud score calculation
def calculate_fraud_score(row):
    score = 0
    score += 3 if row["TransactionAmount"] > 5000 else 0
    score += 2 if row["TransactionTime"] > 1200 else 0  # Late night transactions
    score += 2 * row["IsForeignTransaction"]
    score += 3 * row["IsHighRiskCountry"]
    score += 1 * row["DeviceChange"]
    score += 1 * row["VelocityFlag"]
    score += 1 * row["CardPresent"]
    score += 1 * row["BehaviorDeviation"]
    score += 1 * row["RepeatedPattern"]
    return 1 if score >= 7 else 0

data['IsFraud'] = data.apply(calculate_fraud_score, axis=1)

# Splitting the dataset
features = data.drop(columns=["IsFraud"])
labels = data["IsFraud"]

X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)

# Training RandomForest model
model = RandomForestClassifier()
model.fit(X_train, y_train)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        try:
            transaction_amount = float(request.form['TransactionAmount'])
            transaction_time = float(request.form['TransactionTime'])
            is_foreign = int(request.form['IsForeignTransaction'])
            is_high_risk = int(request.form['IsHighRiskCountry'])
            device_change = int(request.form['DeviceChange'])
            velocity_flag = int(request.form['VelocityFlag'])
            card_present = int(request.form['CardPresent'])
            behavior_deviation = int(request.form['BehaviorDeviation'])
            repeated_pattern = int(request.form['RepeatedPattern'])

            user_input = np.array([transaction_amount, transaction_time, is_foreign, is_high_risk,
                                   device_change, velocity_flag, card_present, behavior_deviation,
                                   repeated_pattern]).reshape(1, -1)

            result = model.predict(user_input)
            prediction = "Fraud Detected!" if result[0] == 1 else "Transaction Safe"
            return render_template('index2.html', prediction=prediction)

        except ValueError as e:
            return render_template('index2.html', error=f"Input error: {e}")

    return render_template('index2.html')

if __name__ == '__main__':
    app.run(debug=True, port=5004)