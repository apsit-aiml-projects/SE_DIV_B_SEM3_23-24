import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class TaskManagerGUI {
    static class Task {
        String title, priority, description;  // Added description
        int id;

        Task(String title, String priority, String description) {  // Updated constructor
            this.title = title;
            this.priority = priority;
            this.description = description;
            this.id = TaskManagerGUI.generateId();
        }

        public String toString() {
            return "[ID: " + id + "] [" + priority + "] " + title + " - " + description;
        }
    }

    static ArrayList<Task> tasks = new ArrayList<>();
    static DefaultListModel<String> taskListModel = new DefaultListModel<>();
    static JList<String> taskList = new JList<>(taskListModel);
    static JTextField titleField = new JTextField(20);
    static JTextField descriptionField = new JTextField(20);  // Added description field
    static JComboBox<String> priorityCombo;
    static int taskIdCounter = 1;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Task Manager");
        frame.setSize(500, 500);  // Increased height to accommodate new components
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(10, 10));

        // Create buttons first
        JButton addButton = new JButton("Add Task");
        JButton deleteButton = new JButton("Delete Task");
        JButton editButton = new JButton("Edit Task");

        // Initialize priorityCombo before using it
        String[] priorities = {"High", "Medium", "Low"};
        priorityCombo = new JComboBox<>(priorities);

        // Input Panel - Change to BoxLayout for vertical alignment
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new BoxLayout(inputPanel, BoxLayout.Y_AXIS));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create sub-panels for each input group
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        titlePanel.add(new JLabel("Task Title:"));
        titlePanel.add(titleField);
        inputPanel.add(titlePanel);

        JPanel descPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        descPanel.add(new JLabel("Description:"));
        descPanel.add(descriptionField);
        inputPanel.add(descPanel);

        JPanel priorityPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        priorityPanel.add(new JLabel("Priority:"));
        priorityPanel.add(priorityCombo);  // Now priorityCombo is initialized
        inputPanel.add(priorityPanel);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(editButton);
        inputPanel.add(buttonPanel);

        // Task List Panel remains the same
        JScrollPane scrollPane = new JScrollPane(taskList);
        taskList.setFixedCellHeight(25);
        taskList.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // Frame components
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Add Edit Task Action
        editButton.addActionListener(e -> {
            int selectedIndex = taskList.getSelectedIndex();
            if (selectedIndex != -1) {
                Task taskToEdit = tasks.get(selectedIndex);
                String newTitle = JOptionPane.showInputDialog(frame, "Enter new title:", taskToEdit.title);
                String newDescription = JOptionPane.showInputDialog(frame, "Enter new description:", taskToEdit.description);
                if (newTitle != null && !newTitle.isEmpty()) {
                    taskToEdit.title = newTitle;
                    taskToEdit.description = newDescription != null ? newDescription : "";
                    taskToEdit.priority = (String) priorityCombo.getSelectedItem();
                    updateTaskList();
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Please select a task to edit");
            }
        });

        // Remove search functionality section completely

        // Add Task Action
        addButton.addActionListener(e -> {
            String title = titleField.getText();
            String description = descriptionField.getText();
            String priority = (String) priorityCombo.getSelectedItem();
            
            if (!title.isEmpty()) {
                Task newTask = new Task(title, priority, description);
                tasks.add(newTask);
                updateTaskList();
                titleField.setText("");
                descriptionField.setText("");
                priorityCombo.setSelectedIndex(0);
            } else {
                JOptionPane.showMessageDialog(frame, "Please enter a task title");
            }
        });

        // Delete Task Action
        deleteButton.addActionListener(e -> {
            int selectedIndex = taskList.getSelectedIndex();
            if (selectedIndex != -1) {
                tasks.remove(selectedIndex);
                updateTaskList();
            } else {
                JOptionPane.showMessageDialog(frame, "Please select a task to delete");
            }
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    static void updateTaskList() {
        taskListModel.clear();
        for (Task task : tasks) {
            taskListModel.addElement(task.toString());
        }
    }

    static int generateId() {
        return taskIdCounter++;
    }
}
