<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Login Form</title>
    <link rel="stylesheet" href="loginstyle.css">
</head>
<body>
    <form class="box" action="login_process.php" method="post">
        <h1>Login</h1>
        <input type="text" name="username" placeholder="Enter Username" required>
        <input type="password" name="password" placeholder="Enter Password" required>
        <input type="submit" value="Login">
        <h6><a href="http://localhost/event%20website/Register.html">Click here to register</a></h6>
    </form>
</body>
</html>
