<?php
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone']; // Updated to 'phone' to match the HTML form field name
$date = $_POST['date'];
$event = $_POST['event'];

// Database connection
$conn = new mysqli('localhost', 'root', '', 'book');
if ($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}

// Check if the date is already booked
$checkQuery = $conn->prepare("SELECT COUNT(*) FROM booking WHERE date = ?");
$checkQuery->bind_param('s', $date);
$checkQuery->execute();
$checkQuery->bind_result($count);
$checkQuery->fetch();
$checkQuery->close();

if ($count > 0) {
    $response = array("Slot already filled. Cannot book on the selected date");
} else {
    // If the date is not booked, proceed to insert the booking
    $stmt = $conn->prepare("INSERT INTO booking (name, email, phone, date, event) VALUES (?,?,?,?,?)");
    $stmt->bind_param('ssiss', $name, $email, $phone, $date, $event);
    $stmt->execute();
    $response = array("Booking successfully...");
}

$conn->close();

echo json_encode($response);
?>
