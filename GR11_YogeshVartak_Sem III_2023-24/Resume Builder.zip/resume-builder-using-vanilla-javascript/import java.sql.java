import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class StudentCourseRegistration {
    private static final String DB_URL = "jdbc:mysql://localhost/register";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static void main(String[] args) {
        String name = "John Doe";
        int roll = 101;
        String division = "A";
        String course = "Computer Science";

        try {
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("Connected to the database!");

            String insertQuery = "INSERT INTO students (name, roll, division, course) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(insertQuery);

            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, roll);
            preparedStatement.setString(3, division);
            preparedStatement.setString(4, course);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Registration successful!");
            } else {
                System.out.println("Registration failed!");
            }

            conn.close();
            System.out.println("Database connection closed.");
        } catch (Exception ex) {
            System.err.println("Error: " + ex);
        }
    }
}
